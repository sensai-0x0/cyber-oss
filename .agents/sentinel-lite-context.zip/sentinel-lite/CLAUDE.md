# Sentinel-Lite: Agent Instructions

Pre-attack threat hunting for **authorized penetration-testing engagements**. One Go MCP stdio binary (`hunter`) does all scanning and enforcement. One LangGraph agent (`agent/graph.py`) decides what to do next. `mission.yaml` bounds both.

## Universal rules (apply to every task)

1. **Scope is law.** No packet leaves the host unless Go code has validated the target against `mission.yaml:targets`. See [.agents/invariants.md](.agents/invariants.md).
2. **Go enforces, the LLM proposes.** Never move a safety check into Python or a prompt. The agent never gets shell access.
3. **The spec wins.** [.agents/architecture.md](.agents/architecture.md) and [.agents/interfaces.md](.agents/interfaces.md) are authoritative. Change the spec file first, then the code.
4. **Follow the idioms.** All code obeys [.agents/language-idioms.md](.agents/language-idioms.md).
5. **Record everything.** Plans, decisions, errors and current state go in [.agents/state-log.md](.agents/state-log.md) before you end a session.
6. **Prove it.** A change is done only when the matching suite in [.agents/testing.md](.agents/testing.md) passes.
7. **Pick the right model.** See [.agents/models.md](.agents/models.md).

## Context index

| File | Read when |
|---|---|
| [.agents/architecture.md](.agents/architecture.md) | Starting any task; orienting in the repo |
| [.agents/invariants.md](.agents/invariants.md) | Touching scanning, mitigation, config, or the MCP boundary |
| [.agents/interfaces.md](.agents/interfaces.md) | Writing Go packages, MCP tools, or `mission.yaml` handling |
| [.agents/agent-graph.md](.agents/agent-graph.md) | Working in `agent/` (LangGraph) |
| [.agents/language-idioms.md](.agents/language-idioms.md) | Writing or reviewing any code |
| [.agents/testing.md](.agents/testing.md) | Before claiming a task is done |
| [.agents/models.md](.agents/models.md) | Choosing a Claude model for a task or for the runtime agent |
| [.agents/state-log.md](.agents/state-log.md) | Start of every session (read) and end (write) |

## Commands

```bash
go build ./cmd/hunter
go test -race ./...
go test ./cmd/hunter/...
pytest agent/tests/test_autonomy.py
```
