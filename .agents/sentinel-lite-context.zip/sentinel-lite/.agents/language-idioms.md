# Language Idioms

Universal rules: [../CLAUDE.md](../CLAUDE.md). These are rules, not suggestions. Reviewers reject code that breaks them.

## Go

Sources: [Effective Go](https://go.dev/doc/effective_go), [Go Code Review Comments](https://go.dev/wiki/CodeReviewComments), [Uber Go Style Guide](https://github.com/uber-go/guide/blob/master/style.md).

**Formatting and naming**
- `gofmt` + `goimports` on every file. `go vet` and `staticcheck` clean.
- Short package names, lowercase, no underscores (`cidr`, `kv`, `probe`). No `util`, `common`.
- MixedCaps. Initialisms stay uppercase: `IP`, `CIDR`, `JARM`, `TTL`, `ID`, `URL`.
- No stutter: `kv.Store`, not `kv.KVStore`.
- Receiver names: one or two letters, consistent. Never `this`/`self`.

**Errors**
- Return errors, never `panic` in library code. Handle each error once: wrap or log, not both.
- Wrap with context: `fmt.Errorf("put cursor %s: %w", cidr, err)`.
- Sentinel errors as `var ErrOutOfScope = errors.New(...)`; match with `errors.Is` / `errors.As`.
- Error strings lowercase, no trailing punctuation.

**Interfaces and types**
- Accept interfaces, return concrete structs (except the spec's constructor contracts).
- Define interfaces where they are consumed; keep them small.
- Verify compliance at compile time: `var _ kv.Store = (*badgerStore)(nil)`.
- Use `netip.Addr` / `netip.Prefix`, not `net.IP`.
- Zero-value structs should be usable or clearly invalid; use constructors for required fields.

**Concurrency**
- `context.Context` is the first parameter of anything that does I/O. Never store it in a struct.
- Every goroutine has a clear exit path tied to a context. No fire-and-forget.
- Channels unbuffered or size 1 unless a bound is justified in a comment.
- Hold `sync.Mutex` as a named unexported field; never embed it. Never copy a mutex.
- Use `errgroup` for fan-out. Run `-race` in CI.

**Other**
- No `init()` side effects; no mutable globals. Pass config explicitly.
- Exit only in `main()`; `main` calls `run() error`.
- Use `time.Duration` for durations, never raw ints.
- Table-driven tests with `t.Run`; use `t.Helper()` in helpers.
- Doc comment on every exported name, starting with the name.

## Python

Sources: [PEP 8](https://peps.python.org/pep-0008/), [PEP 484](https://peps.python.org/pep-0484/) / [typing docs](https://docs.python.org/3/library/typing.html), [PEP 257](https://peps.python.org/pep-0257/).

- Python ≥ 3.11. Format with `ruff format`; lint with `ruff check`; type-check with `mypy --strict` (or `pyright` strict).
- Full type hints on every function. Use `X | None`, `list[str]`, `dict[str, dict]` (PEP 604/585 syntax).
- State is a `TypedDict`; tool payloads are `TypedDict` or Pydantic models mirroring Go JSON tags exactly.
- `snake_case` functions/vars, `PascalCase` classes, `UPPER_CASE` constants.
- No bare `except:`. Catch specific exceptions; re-raise with `from`.
- No mutable default arguments.
- Docstrings (PEP 257) on public modules, classes, functions.
- `pytest` for tests; fixtures in `agent/tests/fixtures/`. Mock the LLM, never call a live model in tests.
- Imports: stdlib, third-party, local; absolute imports only.

## Shared

- JSON field names match the Go struct tags exactly (`snake_case`).
- Comments explain *why*. The code shows *what*.
- Small diffs. One logical change per commit.
